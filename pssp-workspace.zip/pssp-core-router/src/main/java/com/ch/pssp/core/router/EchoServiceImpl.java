package com.ch.pssp.core.router;

import com.ch.pssp.core.intf.EchoService;

public class EchoServiceImpl implements EchoService {

	@Override
	public String sayHello(String echo) {
		return "you say: " + echo;
	}

}
