package com.ch.pssp.core.router;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

import com.ch.pssp.core.intf.EchoService;

import net.hasor.core.AppContext;
import net.hasor.core.Hasor;
import net.hasor.rsf.RsfApiBinder;
import net.hasor.rsf.RsfModule;

@SpringBootApplication
public class RouterBoot extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(RouterBoot.class);
	}

	public static void main(String[] args) throws Throwable {
		//Client
        AppContext clientContext = Hasor.createAppContext("provider-config.xml", new RsfModule() {
            public void loadModule(RsfApiBinder apiBinder) throws Throwable {
                apiBinder.bindType(EchoService.class).toProvider(apiBinder.converToProvider(//
                        apiBinder.rsfService(EchoService.class).toInstance(new EchoServiceImpl()).register()//
                ));
            }
        });
        System.out.println("server start.");
        System.in.read();
	}

}
