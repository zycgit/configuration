package com.ch.pssp.core.intf;

public interface EchoService {
	public String sayHello(String echo);
}
