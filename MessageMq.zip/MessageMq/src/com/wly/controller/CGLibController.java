package com.wly.controller;

import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.wly.inv.CglibProxy;
import com.wly.inv.Login;

import net.hasor.core.AppContext;
import net.hasor.core.Hasor;
import net.hasor.plugins.aop.Aop;
//@Aop(CglibProxy.class)
public class CGLibController extends Controller {

	@ActionKey("/cg")
	public void cg() {
		AppContext appContext = Hasor.createAppContext();
		Login login = appContext.getInstance(Login.class);
		login.cg(this.getRequest(), this.getResponse());
		
		renderJson("{\"message\":\"登录成功\",\"code\":\"200\",\"queue\":\"222\"}");
	}
}
