package com.wly.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.xml.ws.Action;

import com.jfinal.core.ActionKey;
import com.jfinal.core.Controller;
import com.wly.entity.Group;
import com.wly.entity.User;
import com.wly.entity.UserList;
import com.wly.imp.LoginService;
import com.wly.temp.TempData;
import com.wly.utils.GlobalParams;
import com.wly.utils.JsonUtil;

//@Before(LoginInterceptor.class)
public class LoginController extends Controller implements LoginService{

	@ActionKey("/login")
	public void login() {
		TempData.initData();
		String userName = this.getPara("userName");
		String passWord = this.getPara("passWord");
		if (!GlobalParams.userMap.containsKey(userName)) {
			renderJson("{\"message\":\"用户不存在\",\"code\":\"400\"}");
			return;
		}
		if (passWord.equals(GlobalParams.userMap.get(userName).passWord)) {			
			renderJson("{\"message\":\"登录成功\",\"code\":\"200\",\"queue\":\"" + GlobalParams.userMap.get(userName).queue + "\"}");
		}else{
			renderJson("{\"message\":\"密码错误\",\"code\":\"400\"}");
		}
	}
	
	@ActionKey("/getList")
	public void getList(){
		String userName = this.getPara("userName");
		// 获取所在的组
//		Group group = GlobalParams.groupMap.get(userName);
		Set<String> keySet = GlobalParams.groupMap.keySet();
		StringBuffer jsonStr = new StringBuffer();
//		List<Group> groupList = new ArrayList<>();
		jsonStr.append("\"group\":[");
		for(String key : keySet){
			Group group = GlobalParams.groupMap.get(key);
			List<User> userList = group.userList;
			for(User u : userList){
				if (u.userName.equals(userName)) {
					// 如果组内有该用户，则返回组信息
//					groupList.add(group);
					jsonStr./*append("{").*/append(JsonUtil.BeanToJson(group)).append(",");
				}
			}
		}
		String groupStr = jsonStr.substring(0, jsonStr.length() - 1) + "],";
		jsonStr = new StringBuffer();
		Set<String> userSet = GlobalParams.userMap.keySet();
		jsonStr.append("\"user\":[");
		for(String key : userSet){
			User user = GlobalParams.userMap.get(key);
			if (!user.userName.equals(userName)) {//不是本人就返回
				jsonStr./*append("{").*/append(JsonUtil.BeanToJson(user)).append(",");
			}
		}
		String userStr = jsonStr.substring(0, jsonStr.length() - 1) + "]";
		renderJson("{" + groupStr + userStr + "}");
	}
	
	@ActionKey("/getAll")
	public void getAll(){
		String userName = this.getPara("userName");
		// 获取所在的组
//		Group group = GlobalParams.groupMap.get(userName);
		Set<String> keySet = GlobalParams.groupMap.keySet();
		List<UserList> list = new ArrayList<>();
		for(String key : keySet){
			Group group = GlobalParams.groupMap.get(key);
			List<User> userList = group.userList;
			for(User u : userList){
				if (u.userName.equals(userName)) {
					// 如果组内有该用户，则返回组信息
//					groupList.add(group);
					list.add(new UserList(group.groupName, 0, group.groupQueue));
				}
			}
		}
		
		Set<String> userSet = GlobalParams.userMap.keySet();
		
		for(String key : userSet){
			User user = GlobalParams.userMap.get(key);
			if (!user.userName.equals(userName)) {//不是本人就返回
				list.add(new UserList(user.userName, 1, user.queue));
			}
		}
		
		renderJson(JsonUtil.BeanToJson(list));
	}

	@ActionKey("/getAccess")
	public void getAccess() {
		renderJson(JsonUtil.BeanToJson(GlobalParams.userAccess));
	}

}
