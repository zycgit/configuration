package com.wly.mq;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.ConsumerCancelledException;
import com.rabbitmq.client.MessageProperties;
import com.rabbitmq.client.QueueingConsumer;
import com.rabbitmq.client.ShutdownSignalException;
import com.wly.entity.MessageObj;
import com.wly.entity.User;
import com.wly.temp.TempData;
import com.wly.utils.GlobalParams;
import com.wly.utils.JsonUtil;

public class MQServer {
	private static Connection connection;
	private static ConnectionFactory factory;
	
	public static void main(String[] args) throws ShutdownSignalException, ConsumerCancelledException, IOException, TimeoutException, InterruptedException {
		TempData.initData();
		TempData.initGroup();
		TempData.initUserList();
		startServer();
	}

	public static void startServer() throws IOException, TimeoutException, ShutdownSignalException, ConsumerCancelledException, InterruptedException {
		factory = new ConnectionFactory();
		factory.setHost("localhost");
		connection = factory.newConnection();
		Channel channel = connection.createChannel();
		// 声明队列
		boolean durable = true;
		channel.queueDeclare(GlobalParams.SERVER_QUEUE, true, false, false, null);
		// 设置服务器最大消息数
		int prefetchCount = 1;
		channel.basicQos(prefetchCount);
		QueueingConsumer consumer = new QueueingConsumer(channel);
		// 指定消费队列
		boolean ack = false; // 打开应答机制
		channel.basicConsume(GlobalParams.SERVER_QUEUE, ack, consumer);
		
		while (true) {
			QueueingConsumer.Delivery delivery = consumer.nextDelivery();
			String message = new String(delivery.getBody());
			System.out.println(message);
			channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
			MessageObj messageObj = JsonUtil.jsonToBean(message, MessageObj.class);
			sendMessage(messageObj);
		}
	}
	
	
	public static void sendMessage(MessageObj message) throws IOException, TimeoutException{
		Channel channel = connection.createChannel();
		// 声明队列
		boolean durable = true;// 1、设置队列持久化
		List<String> exchangeName = message.exchangeName;
		for(int i = 0; i < exchangeName.size(); i++){
			String queue = exchangeName.get(i);
			if (GlobalParams.isGroupQueue(queue)) {
//				sendGroupMessage(queue, message);
				// 获取组内所有用户
				List<User> userList = GlobalParams.getQueueByGroup(queue);
				// 将消息类型设置为组类型
				message.isGroup = 0;
				message.groupName = GlobalParams.getGroupByQueue(queue);
				for(User u : userList){
					if(u.userName.equals(message.sendUser))
						continue;
					channel.queueDeclare(u.queue, durable, false, false, null);
					channel.basicPublish("", u.queue, MessageProperties.PERSISTENT_TEXT_PLAIN, JsonUtil.BeanToJson(message).getBytes());
				}
			}else{
				// 将消息类型设置为用户类型
				message.isGroup = 1;
				channel.queueDeclare(queue, durable, false, false, null);
				channel.basicPublish("", queue, MessageProperties.PERSISTENT_TEXT_PLAIN, JsonUtil.BeanToJson(message).getBytes());
			}
		}
		

		// 关闭频道和资源
		channel.close();
	}
}
