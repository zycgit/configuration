package com.wly.mq;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeoutException;


import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.QueueingConsumer;
import com.wly.entity.MessageObj;
import com.wly.utils.GlobalParams;
import com.wly.utils.JsonUtil;

public class MQTest {
	private static Connection connection;
	private static ConnectionFactory factory;
	public static void main(String[] args) throws IOException, TimeoutException {
		List<String> exchangeName = new ArrayList<>();
		exchangeName.add("group_001x");
		factory = new ConnectionFactory();
		factory.setHost("192.168.1.232");
		factory.setUsername("mqtest");
		factory.setPassword("mqtest");
		connection = factory.newConnection();
//		for(int i = 1; i <= 10; i++){
			MessageObj message = new MessageObj("hello", exchangeName);
			message.sendUser = "00000111";
			sendMessage(message);
//		}
//		new Scanner(System.in).nextLine();
//		connection.close();
	}
	public static void sendMessage(MessageObj message) throws IOException, TimeoutException{

		Channel channel = connection.createChannel();
		// 声明队列
		boolean durable = true;// 1、设置队列持久化
//		List<String> exchangeName = message.exchangeName;
        channel.queueDeclare("123456", true, false, false, null);
        QueueingConsumer consumer = new QueueingConsumer(channel);
        channel.basicConsume("123456", false, consumer);
        channel.basicPublish("", "123456", null, JsonUtil.BeanToJson(message).getBytes());
//        channel.queueDeclare(GlobalParams.SERVER_QUEUE, true, false, false, null);
//        QueueingConsumer consumer = new QueueingConsumer(channel);
//        channel.basicConsume(GlobalParams.SERVER_QUEUE, false, consumer);
//        channel.basicPublish("", GlobalParams.SERVER_QUEUE, null, JsonUtil.BeanToJson(message).getBytes());
//		for(int i = 0; i < exchangeName.size(); i++){
//			String queue = exchangeName.get(i);
//			if (GlobalParams.isGroupQueue(queue)) {
////				sendGroupMessage(queue, message);
//				// 获取组内所有用户
//				List<User> userList = GlobalParams.getQueueByGroup(queue);
//				// 将消息类型设置为组类型
//				message.isGroup = 0;
//				message.groupName = GlobalParams.getGroupByQueue(queue);
//				for(User u : userList){
//					channel.queueDeclare(u.queue, durable, false, false, null);
//					channel.basicPublish("", u.queue, MessageProperties.PERSISTENT_TEXT_PLAIN, JsonUtil.BeanToJson(message).getBytes());
//				}
//			}else{
//				// 将消息类型设置为用户类型
//				message.isGroup = 1;
//				channel.queueDeclare(queue, durable, false, false, null);
//				channel.basicPublish("", queue, MessageProperties.PERSISTENT_TEXT_PLAIN, JsonUtil.BeanToJson(message).getBytes());
//			}
//		}
		

		// 关闭频道和资源
		channel.close();
//		connection.close();
	}
}
