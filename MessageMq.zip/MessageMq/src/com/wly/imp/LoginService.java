package com.wly.imp;

public interface LoginService {
	
	public void login();

	public void getList();

	public void getAll();
	
	public void getAccess();
	

}
