package com.wly.interceptor;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import com.jfinal.aop.Interceptor;
import com.jfinal.aop.Invocation;
import com.jfinal.core.Controller;
import com.wly.controller.CGLibController;
import com.wly.controller.LoginController;
import com.wly.imp.LoginService;
import com.wly.inv.CglibProxy;
import com.wly.inv.Login;
import com.wly.inv.MyInvocation;
import com.wly.inv.OtInvocation;

import net.hasor.core.AppContext;
import net.hasor.core.Hasor;

public class MyInterceptor implements Interceptor{

	@Override
	public void intercept(Invocation arg0) {
		// -------------------------------------------------------------------
		// JDK动态代理方案
		// ----单层代理方案----
//		MyInvocation invocation = new MyInvocation(arg0.getTarget());
//		LoginService userProxy = invocation.getProxy();
		
		// ----实现多层代理方案----
//		Controller rs = (Controller)arg0.getTarget();
//		Class<?> c = rs.getClass();
//		InvocationHandler myInvocation = new MyInvocation(rs);
//		LoginService proxy$1 = (LoginService) Proxy.newProxyInstance(c.getClassLoader(), c.getInterfaces(), myInvocation);
//		InvocationHandler logHandler = new OtInvocation(proxy$1, rs);
//		LoginService userProxy = (LoginService) Proxy.newProxyInstance(c.getClassLoader(), c.getInterfaces(), logHandler);
//		
//		//---------------------------------------------------
//		Method[] methods = userProxy.getClass().getMethods();
//		for(Method m : methods){
//			if (m.getName().equals(arg0.getMethod().getName())) {
//				try {
//					m.invoke(userProxy, null);
//					break;
//				} catch (IllegalAccessException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (IllegalArgumentException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				} catch (InvocationTargetException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		}
		
		
		// ---------------------------------------------------------------------------
		arg0.invoke();
	}
	

}
