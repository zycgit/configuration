package com.wly.temp;

import java.util.ArrayList;
import java.util.List;

import com.wly.entity.Group;
import com.wly.entity.User;
import com.wly.utils.GlobalParams;

public class TempData {
	private static boolean isInit = false;
	
	public static void initData(){
		if(!isInit){
			initUserList();
			initGroup();
			isInit = true;
		}
	}
	
	// 初始化用户列表 (模拟数据库)
	public static void initUserList(){
		GlobalParams.userMap.put("000001", new User("000001", "111111", "000001x"));
		GlobalParams.userMap.put("000002", new User("000002", "111111", "000002x"));
		GlobalParams.userMap.put("000003", new User("000003", "111111", "000003x"));
		GlobalParams.userMap.put("000004", new User("000004", "111111", "000004x"));
		GlobalParams.userMap.put("000005", new User("000005", "111111", "000005x"));
		GlobalParams.userMap.put("000006", new User("000006", "111111", "000006x"));
		GlobalParams.userMap.put("000007", new User("000007", "111111", "000007x"));
	}
	
	// 初始化群组 (模拟数据库)
	public static void initGroup(){
		List<User> userList = new ArrayList<>();
		userList.add(GlobalParams.userMap.get("000001"));
		userList.add(GlobalParams.userMap.get("000002"));
		userList.add(GlobalParams.userMap.get("000004"));
		userList.add(GlobalParams.userMap.get("000005"));
		userList.add(GlobalParams.userMap.get("000006"));
		GlobalParams.groupMap.put("group_001", new Group("group_001", "group_001x", userList));
		
		userList.clear();
		userList.add(GlobalParams.userMap.get("000001"));
		userList.add(GlobalParams.userMap.get("000003"));
		userList.add(GlobalParams.userMap.get("000005"));
		userList.add(GlobalParams.userMap.get("000006"));
		userList.add(GlobalParams.userMap.get("000007"));
		GlobalParams.groupMap.put("group_002", new Group("group_002", "group_002x", userList));
	}
	
}
