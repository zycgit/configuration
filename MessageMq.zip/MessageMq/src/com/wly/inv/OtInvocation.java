package com.wly.inv;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.jfinal.core.Controller;
import com.wly.entity.UserAccess;
import com.wly.utils.GlobalParams;
import com.wly.utils.JsonUtil;


public class OtInvocation extends BaseInvocation {

	private Object target;
	private Controller cr;

	public OtInvocation(Object target, Controller cr) {
		super();
		this.target = target;
		this.cr = cr;
	}

	@Override
	public Object invoke(Object o, Method method, Object[] args) throws Throwable {
		System.out.println("OtInvo代理日志输出");
		HttpServletRequest request = cr.getRequest();
		System.out.println("请求参数：" + JsonUtil.BeanToJson(request.getParameterMap()) + "\n\n");
		Object result = method.invoke(target, args);
		return result;
	}

}
