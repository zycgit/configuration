package com.wly.inv;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import javax.servlet.http.HttpServletRequest;

public abstract class BaseInvocation implements InvocationHandler {

	protected Object target;
	
	@Override
	public abstract Object invoke(Object proxy, Method method, Object[] args) throws Throwable;

	/** 
     * 获取目标对象的代理对象 
     * @return 代理对象 
     */  
    @SuppressWarnings("unchecked")
	public <T> T getProxy() {  
//    	StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
//    	int i = 1;
//    	for(StackTraceElement stack : stackTrace){
//    		System.out.println("\n\n数据" + (i++) + "的值：\n类名：" + stack.getClassName() + "\n文件名：" + stack.getFileName() + "\n调用行数：" + stack.getLineNumber() + "\n调用方法：" + stack.getMethodName() + "()\n\n------------------------------------------------------");
//    	}
//    	System.out.println("调用类：" + Thread.currentThread().getStackTrace()[2].getFileName() + "，行数：" + Thread.currentThread().getStackTrace()[2].getLineNumber());
        return (T)Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(),   
                target.getClass().getInterfaces(), this);  
    }  
    
    public String getClientIP(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (null == ip || 0 == ip.length() || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (null == ip || 0 == ip.length() || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (null == ip || 0 == ip.length() || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("X-Real-IP");
		}
		if (null == ip || 0 == ip.length() || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}
	
}
