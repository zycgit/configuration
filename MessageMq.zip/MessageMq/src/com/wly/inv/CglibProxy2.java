package com.wly.inv;

import java.lang.reflect.Method;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

public class CglibProxy2 implements MethodInterceptor {

	private Enhancer enhancer = new Enhancer();
	
	@SuppressWarnings("unchecked")
	public <T> T createProxy(Class<?> c){
		enhancer.setSuperclass(c);
		enhancer.setCallback(this);
		return (T)enhancer.create();
	}
	
	@Override
	public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
		// TODO Auto-generated method stub
		System.out.println("doBefore");
		Object result = proxy.invokeSuper(obj, args);
		System.out.println("doAfter");
		return result;
	}

}
