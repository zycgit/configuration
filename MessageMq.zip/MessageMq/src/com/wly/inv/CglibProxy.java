package com.wly.inv;

import net.hasor.core.MethodInterceptor;
import net.hasor.core.MethodInvocation;

public class CglibProxy implements MethodInterceptor {

	@Override
	public Object invoke(MethodInvocation arg0) throws Throwable {
		System.out.println("before");
		Object result = arg0.proceed();
		System.out.println("after");
		return result;
	}

//	private Enhancer enhancer = new Enhancer();
//	
//	@SuppressWarnings("unchecked")
//	public <T> T createProxy(Class<?> c){
//		enhancer.setSuperclass(c);
//		enhancer.setCallback(this);
//		return (T)enhancer.create();
//	}
//	
//	@Override
//	public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
//		// TODO Auto-generated method stub
//		System.out.println("doBefore");
//		Object result = proxy.invokeSuper(obj, args);
//		System.out.println("doAfter");
//		return result;
//	}

}
