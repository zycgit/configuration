package com.wly.inv;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wly.controller.CGLibController;
import com.wly.temp.TempData;

import net.hasor.core.AppContext;
import net.hasor.core.Hasor;
import net.hasor.plugins.aop.Aop;
@Aop(CglibProxy.class)
public class Login {
	
	public static void main(String[] args) {
		AppContext appContext = Hasor.createAppContext();
		CGLibController login = appContext.getInstance(CGLibController.class);
		login.cg();
	}
	
	public boolean cg(HttpServletRequest req, HttpServletResponse res) {
		TempData.initData();
		String userName = req.getParameter("userName");
		System.out.println(userName);
		return true;
	}
}
