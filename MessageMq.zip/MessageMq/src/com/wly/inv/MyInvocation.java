package com.wly.inv;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.jfinal.core.Controller;
import com.wly.entity.UserAccess;
import com.wly.utils.GlobalParams;
import com.wly.utils.JsonUtil;


public class MyInvocation extends BaseInvocation {

	private Object target;

	public MyInvocation(Object target) {
		super();
		this.target = target;
	}

	@Override
	public Object invoke(Object o, Method method, Object[] args) throws Throwable {
		HttpServletRequest request = ((Controller)target).getRequest();
		String clientIP = getClientIP(request);
		// 不记录获取统计数据接口访问次数
		if (!"getAccess".equals(method.getName())) {
			// 保存访问数据
			if (GlobalParams.userAccess.containsKey(clientIP)) {
				UserAccess access = GlobalParams.userAccess.get(clientIP);
				// 判断该用户是否访问过这个接口
				if (null != access.accessCount && access.accessCount.containsKey(method.getName())) {
					// 如果接口已经访问过，则增加访问次数
					access.accessCount.put(method.getName(), access.accessCount.get(method.getName()) + 1);
				} else {
					access.accessCount.put(method.getName(), 1);
				}
				// 将访问的接口添加到集合
				access.access.add(method.getName());
			} else {
				UserAccess userAccess = new UserAccess();
				userAccess.ipAddress = clientIP;
				// 有序的将访问的接口添加入集合
				userAccess.access = new ArrayList<>();
				userAccess.access.add(method.getName());
				// 加入次数
				Map<String, Integer> count = new HashMap<>();
				count.put(method.getName(), 1);
				userAccess.accessCount = count;
				GlobalParams.userAccess.put(clientIP, userAccess);
			}
		}
		System.out.println("来自IP地址为：" + clientIP + "的用户调用方法：" + method.getName());
		System.out.println("请求参数：" + JsonUtil.BeanToJson(request.getParameterMap()));
		Object result = method.invoke(target, args);
		System.out.println("方法返回结果：" + (result == null ? "该方法无返回值" : result.toString()));
		return result;
	}

}
