package com.wly.entity;

import java.util.ArrayList;
import java.util.Map;

/**
 * 用户访问接口以及次数(LinkedHashMap)
 */
public class UserAccess {
	// 访问者IP
	public String ipAddress;
	// 访问的地址(有序保存，可以查看用户访问的流程)
	public ArrayList<String> access;
	// 访问次数(接口对应次数)
	public Map<String, Integer> accessCount;
	@Override
	public String toString() {
		return "UserAccess [ipAddress=" + ipAddress + ", access=" + access + ", accessCount=" + accessCount + "]";
	}
	
}
