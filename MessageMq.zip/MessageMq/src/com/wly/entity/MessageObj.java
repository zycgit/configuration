package com.wly.entity;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.wly.utils.GlobalParams;


public class MessageObj {
    private final int VEERSION_CODE = 0x1;// 消息版本号
    public String messageId;// 消息ID
    public String content;// 消息内容
    public String sendUser;// 发送人
    public long createTime;// 消息创建时间
    public int isGroup;// 是否组消息 0是，1否
    public String groupName;// 收到消息的群
    public int level = 7; // 消息等级 1-10，默认7
    public List<String> messageType;//消息类型
    public List<String> transmitType;// 转发类型： 邮件、短信、消息
    public List<String> exchangeName; // 接收人/组通道名

    
    
    public MessageObj() {
		super();
	}

	/**
     * 使用默认形式发送消息
     */
    public MessageObj(String content, List<String> exchangeName) {
        initMessage();
        // 消息内容
        this.content = content;
        // 消息等级默认7
        this.level = 7;
        // 接收人/组通道名
        this.exchangeName = exchangeName;
        // 默认发送类型：消息
        this.transmitType = setType("message");
    }

    /**
     * 指定消息发送形式
     */
    public MessageObj(String content, List<String> messageType, List<String> transmitType, List<String> exchangeName, int level) {
        this.content = content;
        this.messageType = messageType;
        this.transmitType = transmitType;
        this.exchangeName = exchangeName;
        this.level = level;
        initMessage();
    }

    /**
     * 初始化共有属性
     */
    private void initMessage() {
        // 生成随机消息ID
        this.messageId = UUID.randomUUID().toString().replace("-", "");
//        // 发送人，当前用户，默认
//        this.sendUser = GlobalParams.uid;
        // 消息创建时间
        this.createTime = new Date().getTime();
    }

    // 快捷设置消息转发类型
    public List<String> setType(String... type) {
        List<String> tranType = new ArrayList<>();
        for (String t : type) {
            tranType.add(t);
        }
        return tranType;
    }

}
