package com.wly.entity;

import java.util.List;

public class Group {
	public String groupName; // 组名
	public String groupQueue;// 组通道
	public List<User> userList;// 组内用户列表
	public Group(String groupName, String groupQueue, List<User> userList) {
		super();
		this.groupName = groupName;
		this.groupQueue = groupQueue;
		this.userList = userList;
	}
	@Override
	public String toString() {
		return "Group [groupName=" + groupName + ", groupQueue=" + groupQueue + ", userList=" + userList + "]";
	}
	
}
