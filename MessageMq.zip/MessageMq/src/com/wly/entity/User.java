package com.wly.entity;

public class User {
	public String userName;
	public String passWord;
	public String queue;//ͨ通道
	public User(String userName, String passWord, String queue) {
		super();
		this.userName = userName;
		this.passWord = passWord;
		this.queue = queue;
	}
	@Override
	public String toString() {
		return "User [userName=" + userName + ", passWord=" + passWord + ", queue=" + queue + "]";
	}
	
}
