package com.wly.entity;

public class UserList {
	public String name;
	public int type;// 0 group , 1 user
	public String message;
	public String queue;
	public UserList(String name, int type, String queue) {
		super();
		this.name = name;
		this.type = type;
		this.queue = queue;
	}
	
}
