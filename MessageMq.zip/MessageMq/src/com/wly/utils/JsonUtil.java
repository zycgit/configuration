package com.wly.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class JsonUtil {

	/**
	 * 
	 * @param jsonString
	 *            Json转Bean
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static <T> T jsonToBean(String jsonString, Class<T> pojoCalss) {
		if (jsonString == null || jsonString.length() == 0) {
			return null;
		}
		//		try {
//			ObjectMapper objMapper = new ObjectMapper();
//			objMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
//			objMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//			objMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
//			pojo = objMapper.readValue(jsonString, pojoCalss);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		if (pojo == null) {
//			try {
//				pojo = pojoCalss.newInstance();
//			} catch (Exception e) {
//			}
//		}
		return JSON.parseObject(jsonString, pojoCalss);
	}

	/**
	 * Object json�?�?bean
	 * 
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static <T> T jsonToBean(Object object, Class<T> pojoCalss) {
		if (object == null) {
			return null;
		}
		return jsonToBean(BeanToJson(object), pojoCalss);
	}

	/**
	 * @param obj
	 * @return
	 */
	public static String BeanToJson(Object obj) {
		if (obj == null) {
			return null;
		}
		//		try {
//			ObjectMapper mapper = new ObjectMapper();
//			mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
//			ret = mapper.writeValueAsString(obj);
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		}
		return JSON.toJSONString(obj);
	}

	/**
	 * map转json
	 * 
	 * @param map
	 * @return
	 */
	public static String mapToJson(Map<String, String> map) {
		if (map == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		sb.append("{");
		for (Entry<String, String> entry : map.entrySet()) {
			sb.append("\"" + entry.getKey() + "\"");
			sb.append(":");
			sb.append("\"" + entry.getValue() + "\"");
			sb.append(",");
		}
		if (sb.length() > 1) {
			sb.deleteCharAt(sb.length() - 1);
		}
		sb.append("}");
		return sb.toString();
	}

	/**
	 * map转bean
	 * 
	 * @param map
	 * @param pojoCalss
	 * @return
	 */
	public static <T> T mapToBean(Map<String, String> map, Class<T> pojoCalss) {
		if (map == null) {
			return null;
		}
		return jsonToBean(mapToJson(map), pojoCalss);
	}

	/**
	 * list嵌套map转bean对象集合
	 * 
	 * @param list
	 * @param pojoCalss
	 * @return
	 */
	public static <T> List<T> listMapTobeanList(List<Map<String, String>> list, Class<T> pojoCalss) {
		if (list == null) {
			return null;
		}
		List<T> beanList = new ArrayList<>();
		for (int i = 0; i < list.size(); i++) {
			beanList.add(mapToBean(list.get(i), pojoCalss));
		}
		return beanList;
	}

	/**
	 * JSON转bean对象集合
	 * 
	 * @param json
	 * @param pojoCalss
	 * @return
	 */
	public static <T> List<T> jsonToBeanList(String json, Class<T> pojoCalss) {
		if (json == null || json.equals("")) {
			return null;
		}
		JSONArray jsonArray = JSONArray.parseArray(json);
		List<T> list = new ArrayList<>();
		if (jsonArray != null) {
			for (int i = 0; i < jsonArray.size(); i++) {
				list.add(jsonToBean(jsonArray.get(i), pojoCalss));
			}
		}
		return list;
	}

	/**
	 * Object 转bean对象集合
	 * 
	 * @param object
	 * @param pojoCalss
	 * @return
	 */
	public static <T> List<T> jsonToBeanList(Object object, Class<T> pojoCalss) {
		if (object == null) {
			return null;
		}
		return jsonToBeanList(BeanToJson(object), pojoCalss);
	}


	/**
	 * 取出JSON串里指定的key对应的int
	 * @param json
	 * @param key
	 * @return
	 */
	public static int getInt(String json,String key) {
		if(json == null || key == null || json.length() == 0 || key.length() == 0) {
			return 0;
		}
		return JSON.parseObject(json).getIntValue(key);
	}


	/**
	 * 取出JSON串里指定的key对应的String对象
	 * @param json
	 * @param key
	 * @return
	 */
	public static String getString(String json,String key) {
		if(json == null || key == null || json.length() == 0 || key.length() == 0) {
			return null;
		}
		return JSON.parseObject(json).getString(key);
	}


	/**
	 * 取出JSON串里指定的key对应的double
	 * @param json
	 * @param key
	 * @return
	 */
	public static double getDouble(String json,String key) {
		if(json == null || key == null || json.length() == 0 || key.length() == 0) {
			return 0;
		}
		return JSON.parseObject(json).getDoubleValue(key);
	}

	public static long getLong(String json,String key) {
		if(json == null || key == null || json.length() == 0 || key.length() == 0) {
			return 0;
		}
		return JSON.parseObject(json).getLongValue(key);
	}


	/**
	 * 取出JSON串里指定的key对应的Object对象
	 * @param json
	 * @param key
	 * @return
	 */
	public static Object getObject(String json,String key) {
		if(json == null || key == null || json.length() == 0 || key.length() == 0) {
			return null;
		}
		return JSON.parseObject(json).get(key);
	}


	/**
	 * 取出JSON串里指定的key对应的jsonArray对象
	 * @param json
	 * @param key
	 * @return
	 */
	public static JSONArray getjsonArray(String json,String key) {
		if(json == null || key == null || json.length() == 0 || key.length() == 0) {
			return null;
		}
		return JSON.parseObject(json).getJSONArray(key);
	}

	/**
	 * 取出JSON串里指定的key对应的jsonObject对象
	 * @param json
	 * @param key
	 * @return
	 */
	public static JSONObject getJsonObject(String json,String key) {
		if(json == null || key == null || json.length() == 0 || key.length() == 0) {
			return null;
		}
		return JSON.parseObject(json).getJSONObject(key);
	}
	
	
	
	
	
	
	/**
	 * 根据key找json串里对应的json�?
	 * 
	 * @param jsonStr
	 * @param key
	 * @return
	 */
	public static String getJsonFromKeyAtJson(String jsonStr, String key) {
		if (jsonStr == null || key == null) {
			return null;
		}
		return BeanToJson(getJsonObject(jsonStr, key));
	}

	/**
	 * 根据key找json串里对应的json�?
	 * 
	 * @param obj
	 * @param key
	 * @return
	 */
	public static String getJsonFromKeyAtObj(Object obj, String key) {
		if (obj == null || key == null) {
			return null;
		}
		String beanJson = BeanToJson(obj);
		return getJsonFromKeyAtJson(beanJson, key);
	}

	/**
	 * 根据key找json串里对应的json�?目标json串为[]集合格式)
	 * 
	 * @param jsonStr
	 * @param key
	 * @return
	 */
	public static String getListJsonFromKeyAtJson(String jsonStr, String key) {
		if (jsonStr == null || key == null) {
			return null;
		}
		return BeanToJson(getjsonArray(jsonStr,key));
	}

	/**
	 * 根据key找json串里对应的json�?
	 * 
	 * @param obj
	 * @param key
	 * @return
	 */
	public static String getListJsonFromKeyAtObj(Object obj, String key) {
		if (obj == null || key == null) {
			return null;
		}
		String beanJson = BeanToJson(obj);
		return getListJsonFromKeyAtJson(beanJson, key);
	}

	/**
	 * 对象转json
	 * 
	 * @param obj
	 * @return
	 */
	public static String toJSONString(Object obj) {
		if (obj == null) {
			return null;
		}
		return JSONObject.toJSONString(obj);
	}
}
