package com.wly.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.wly.entity.Group;
import com.wly.entity.User;
import com.wly.entity.UserAccess;

public class GlobalParams {
	// 用户列表数据
	public static Map<String, User> userMap = new HashMap<>(); 
	// 组数据
	public static Map<String, Group> groupMap = new HashMap<>();
	// 总通道名
	public static final String SERVER_QUEUE = "SERVER_QUEUE";
	// 用户访问接口(用户IP对应访问)
	public static Map<String, UserAccess> userAccess = new HashMap<>();
	
	// 判断是组通道还是单用户通道
	public static boolean isGroupQueue(String queue){
		Set<String> keySet = userMap.keySet();
		for(String key : keySet){
			User user = userMap.get(key);
			if (user.queue.equals(queue)) {// 如果在用户通道中含有此通道名，则表示为用户通道，非组通道
				return false;
			}
		}
		// 如果在用户通道中不包含，则是组通道 
		return true;
	}
	
	// 通过通道名获取组名
	public static String getGroupByQueue(String queue){
		Set<String> keySet = groupMap.keySet();
		for(String key : keySet){
			Group group = groupMap.get(key);
			if (group.groupQueue.equals(queue)) {
				return group.groupName;
			}
		}
		return null;
	}
	
	// 通过组名获取内所有成员
	public static List<User> getQueueByGroup(String queue){
		String groupName = getGroupByQueue(queue);
		Group group = groupMap.get(groupName);
		return group.userList;
	}
}
